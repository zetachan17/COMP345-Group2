This image is used with permission of the Star Wars Deckplan Alliance.  Please, keep in mind the following details concerning this image fromthe Star Wars Deckplan Alliance [http://deckplans.00sf.com].

STAR WARS� � � and everything intellectually, written, or graphically related to it, is wholly the property of Lucasfilm Ltd. and its creator, George Lucas. STAR WARS The Roleplaying Game is currently licensed to Wizards of the Coast, and was formerly under the care of WEST END GAMES. No copyright infringement is intended.

All of the ships contained herein are drawn by myself [Frank V. Bonura], with the help of my friends. They are based on existing ships in the SWRPG, books, or movies. I do not claim any rights or credit to these ships, only to my drawings and deckplans, which are based on them. The internal systems in these ships are of my own creation. In most cases, the deckplans are my own as well, due to the lack of proper deckplans by the original artists. I either expand upon and improve existing deckplans, or I have to create my own from scratch. The ships themselves are copyrighted to the original artists.

